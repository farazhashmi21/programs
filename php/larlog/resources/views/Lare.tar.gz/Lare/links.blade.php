<!-- A grey horizontal navbar that becomes vertical on small screens -->
<nav class="navbar navbar-expand-sm bg-light">
  <!-- Links -->
  <ul class="navbar-nav">
  <li class="nav-item"><a  class="nav-link" href="/" data-toggle="tooltip" data-placement="left"  title="Home">Home</a></li>
  <li class="nav-item"><a  class="nav-link" href="/about" data-toggle="tooltip" data-placement="bottom"  title="About">About</a></li>
  <li class="nav-item"><a  class="nav-link" href="/services" data-toggle="tooltip" data-placement="top" title="Services">Services</a></li>
  <li class="nav-item"><a  class="nav-link" href="/contact" data-toggle="tooltip" data-placement="right" title="Contact">Contact</a></li>
  </ul>
</nav> 
